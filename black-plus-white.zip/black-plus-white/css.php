 <!-- Loading Bootstrap -->
    <link href="css\bootstrap.min.css" rel="stylesheet">

    <!-- Loading Template CSS -->
    <link href="css\style.css" rel="stylesheet">
    <link href="css\animate.css" rel="stylesheet">
    <link rel="stylesheet" href="css\pe-icon-7-stroke.css">
    <link href="css\style-magnific-popup.css" rel="stylesheet">

    <!-- Awsome Fonts -->
    <link rel="stylesheet" href="css\all.min.css">

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,400i&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Roboto:400,500&display=swap" rel="stylesheet">

    <!-- Font Favicon -->
    <link rel="shortcut icon" href="images\favicon.ico">

    <link rel="stylesheet" type="text/css" href="css/custom.css">