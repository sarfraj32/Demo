<script src="js\jquery-3.3.1.min.js"></script>
<script src="js\bootstrap.min.js"></script>
<script src="js\jquery.scrollTo-min.js"></script>
<script src="js\jquery.magnific-popup.min.js"></script>
<script src="js\jquery.nav.js"></script>
<script src="js\wow.js"></script>
<script src="js\plugins.js"></script>
<script src="js\custom.js"></script>


<script type="text/javascript">
	$('.nav-item.dropdown').hover(function(){
		$('this').addClass('show');
		$('.dropdown-menu.dropdownhover-bottom').addClass('show');

	});
</script>