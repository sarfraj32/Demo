 <div class="footer">
            
        <!--begin container -->
        <div class="container footer-top">
        
            <!--begin row -->
            <div class="row">
            
                <!--begin col-md-4 -->
                <div class="col-md-4 text-center">
                   
                    <i class="pe-7s-map-2"></i>

                    <h5>Get In Touch</h5>

                    <p>10 Oxford Street, London, UK, E1 1EC</p>
                    
                    <p><a href="mailto:contact@youremail.com">the-office@leadpage.co.uk</a></p>
                    
                    <p>+44 987 654 321</p>
                    
                </div>
                <!--end col-md-4 -->
                
                <!--begin col-md-4 -->
                <div class="col-md-4 text-center">
                   
                    <i class="pe-7s-comment"></i>

                    <h5>Social Media</h5>

                    <p>See bellow where you can find us.</p>
                                         
                    <!--begin footer_social -->
                    <ul class="footer_social">

                        <li><a href="#"><i class="fab fa-twitter"></i></a></li>

                        <li><a href="#"><i class="fab fa-pinterest"></i></a></li>

                        <li><a href="#"><i class="fab fa-facebook-square"></i></a></li>

                        <li><a href="#"><i class="fab fa-instagram"></i></a></li>

                        <li><a href="#"><i class="fab fa-skype"></i></a></li>

                        <li><a href="#"><i class="fab fa-dribble"></i></a></li>

                    </ul>
                    <!--end footer_social -->
                    
                </div>
                <!--end col-md-4 -->
                
                <!--begin col-md-4 -->
                <div class="col-md-4 text-center">
                   
                    <i class="pe-7s-link"></i>

                    <h5>Useful Links</h5>

                    <a href="#" class="footer-links">Our Cookies Policy</a>

                    <a href="#" class="footer-links">Meet The Team Behind LeadPage</a>

                    <a href="#" class="footer-links">Terms and Conditions</a>
                    
                </div>
                <!--end col-md-4 -->
                
            </div>
            <!--end row -->

        </div>
        <!--end container -->
                
        <!--begin container -->
        <div class="container-fluid footer-bottom px-0">
        
            <!--begin row -->
            <div class="row no-gutters mx-0">
            
            
                <!--begin col-md-12 -->
                <div class="col-md-12 text-center">
                   
                    <p>Copyright © 2020 <b>Black Plus White</b></p>
                    
                </div>
                <!--end col-md-6 -->
                
            </div>
            <!--end row -->
            
        </div>
        <!--end container -->
                
    </div>