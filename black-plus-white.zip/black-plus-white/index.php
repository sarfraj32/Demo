<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
      <meta name="keywords" content="">
      <meta name="description" content="">
      <title>demo</title>
      <!-- css files -->
      <?php include 'css.php'; ?>
   </head>
   <body>
      <!--begin header -->
      <?php include 'header.php'; ?>
      <!--end header -->
      <!--begin home section -->
      <section class="home-section" id="home">
         <div class="home-section-overlay"></div>
         <!--begin container -->
         <div class="container">
            <!--begin row -->
            <div class="row">
               <!--begin col-md-12-->
               <div class="col-md-12 text-center" style="position: relative;">
                  <h1>The World's Best Meal Kit</h1>
                  <p class="hero-text">Delivered to your door, ready to eat in minutes.</p>
                  <a href="#start" class="btn-green scrool">Contact Us</a><br>
                  <a href="#start" class="arrow-down scrool"><i class="pe-7s-angle-down-circle"></i></a>
               </div>
               <!--end col-md-12-->
            </div>
            <!--end row -->
         </div>
         <!--end container -->
      </section>
      <!--end home section -->
      <!--begin about section -->
      <section class="section-grey section-bottom-border" id="about">
         <!--begin container -->
         <div class="container">
            <!--begin row -->
            <div class="row">
               <!--begin col-md-12 -->
               <div class="col-md-12 text-center padding-bottom-20">
                  <h2 class="section-title">About Us</h2>
                  <div class="double-line-bottom-centered-theme-colored-2 mt-20"></div>
                  <p class="">'Morphologically the Black Plus White "An Pan-Asian Kitchen & Bar" reveals a marked radiation imprint through iconic design. A stripped B+W facade patron on the wall, an imposing 5 meter 'Modular Shelving Box System' consisting of a unique elements of our life. The Authentic taste of the origin, with Spirits for the perfect combination.</p> 
                  <p>A cozy ambiance embedded in the feel from inside "obsession to create something beautiful," a synthetic and forceful sentence. Black plus White is a perfect Destination for Corporate, Families and Friends. We carter a unique experience From Hi-speed WiFi to Conference Room, Fun filled board games to Books & Magazine to read, with a lavish feel all together</p>

                  </p>
               </div>
               <!--end col-md-12 -->
            </div>
            <!--end row -->
         </div>
         <!--end container -->
      </section>
      <!--end about section-white-->
     
      
      <!--begin testimonials section -->
      <section class="section-white section-top-border section-bottom-border">
         <!--begin container -->
         <div class="container">
            <!--begin row -->
            <div class="row">
               <!--begin col-md-12 -->
               <div class="col-md-12 text-center padding-bottom-40">
                  <h2 class="section-title">Clients Testimonials</h2>
                  <div class="double-line-bottom-centered-theme-colored-2 mt-20"></div>
                  <p class="section-subtitle">What Our Clients Are Saying.</p>
               </div>
               <!--end col-md-12 -->
               <!--begin col-md-4 -->
               <div class="col-md-4">
                  <!--begin testim-inner -->
                  <div class="testim-inner first">
                     <img src="images\testimonials3.jpg" alt="testimonials" class="testim-img">
                     <p>The attention of a traveller, should be particularly turned to the various works of nature.</p>
                     <h6>Emily Richards<span class="job-text"> - Copywriter</span></h6>
                     <div class="testim-rating">
                        <i class="fa fa-star" aria-hidden="true"></i>
                        <i class="fa fa-star" aria-hidden="true"></i>
                        <i class="fa fa-star" aria-hidden="true"></i>
                        <i class="fa fa-star" aria-hidden="true"></i>
                        <i class="fa fa-star" aria-hidden="true"></i>
                     </div>
                  </div>
                  <!--end testim-inner -->
               </div>
               <!--end col-md-4 -->
               <!--begin col-md-4 -->
               <div class="col-md-4">
                  <!--begin testim-inner -->
                  <div class="testim-inner">
                     <img src="images\testimonials2.jpg" alt="testimonials" class="testim-img">
                     <p>The attention of a traveller, should be particularly turned to the various works of nature.</p>
                     <h6>John Doe<span class="job-text"> -  General Manager</span></h6>
                     <div class="testim-rating">
                        <i class="fa fa-star" aria-hidden="true"></i>
                        <i class="fa fa-star" aria-hidden="true"></i>
                        <i class="fa fa-star" aria-hidden="true"></i>
                        <i class="fa fa-star" aria-hidden="true"></i>
                        <i class="fa fa-star" aria-hidden="true"></i>
                     </div>
                  </div>
                  <!--end testim-inner -->
               </div>
               <!--end col-md-4 -->
               <!--begin col-md-4 -->
               <div class="col-md-4">
                  <!--begin testim-inner -->
                  <div class="testim-inner">
                     <img src="images\testimonials1.jpg" alt="testimonials" class="testim-img">
                     <p>The attention of a traveller, should be particularly turned to the various works of nature.</p>
                     <h6>Jane Smith<span class="job-text"> - Web Designer</span></h6>
                     <div class="testim-rating">
                        <i class="fa fa-star" aria-hidden="true"></i>
                        <i class="fa fa-star" aria-hidden="true"></i>
                        <i class="fa fa-star" aria-hidden="true"></i>
                        <i class="fa fa-star" aria-hidden="true"></i>
                        <i class="fa fa-star" aria-hidden="true"></i>
                     </div>
                  </div>
                  <!--end testim-inner -->
               </div>
               <!--end col-md-4 -->
            </div>
            <!--end row -->
         </div>
         <!--end container -->
      </section>
      <!--end testimonials section -->
      <!--begin gallery section -->
      <section class="section-grey" id="gallery">
         <!--begin container -->
         <div class="container">
            <!--begin row -->
            <div class="row">
               <!--begin col-md-12 -->
               <div class="col-md-12 text-center padding-bottom-20">
                  <h2 class="section-title">Gallery</h2>
                  <div class="double-line-bottom-centered-theme-colored-2 mt-20"></div>
                  <p class="section-subtitle">Curabitur quam etsum lacus net netsum nulat netus netsum.</p>
               </div>
               <!--end col-md-12 -->
            </div>
            <!--end row -->
         </div>
         <!--end container -->
         <!--begin container -->
         <div class="container">
            <!--begin row-->
            <div class="row">
               <!--begin col-md-3 -->
               <div class="col-md-3 col-sm-3 col-xs-6">
                  <figure class="gallery-insta">
                     <!--begin popup-gallery-->
                     <div class="popup-gallery popup-gallery-rounded portfolio-pic">
                        <a class="popup2" href="images\DSC_1155.jpg">
                        <img src="images\DSC_1155.jpg" class="width-100" alt="pic">
                        <span class="eye-wrapper"><i class="fa fa-search-plus eye-icon" style="font-size: 38px;"></i></span>
                        </a>
                     </div>
                     <!--end popup-gallery-->
                  </figure>
               </div>
               <!--end col-md-3 -->
               <!--begin col-md-3 -->
               <div class="col-md-3 col-sm-3 col-xs-6">
                  <figure class="gallery-insta">
                     <!--begin popup-gallery-->
                     <div class="popup-gallery popup-gallery-rounded portfolio-pic">
                        <a class="popup2" href="images\DSC_1164.jpg">
                        <img src="images\DSC_1164.jpg" class="width-100" alt="pic">
                        <span class="eye-wrapper"><i class="fa fa-search-plus eye-icon" style="font-size: 38px;"></i></span>
                        </a>
                     </div>
                     <!--end popup-gallery-->
                  </figure>
               </div>
               <!--end col-md-3 -->
               <!--begin col-md-3 -->
               <div class="col-md-3 col-sm-3 col-xs-6">
                  <figure class="gallery-insta">
                     <!--begin popup-gallery-->
                     <div class="popup-gallery popup-gallery-rounded portfolio-pic">
                        <a class="popup2" href="images\DSC_1165.jpg">
                        <img src="images\DSC_1165.jpg" class="width-100" alt="pic">
                        <span class="eye-wrapper"><i class="fa fa-search-plus eye-icon" style="font-size: 38px;"></i></span>
                        </a>
                     </div>
                     <!--end popup-gallery-->
                  </figure>
               </div>
               <!--end col-md-3 -->
               <!--begin col-md-3 -->
               <div class="col-md-3 col-sm-3 col-xs-6">
                  <figure class="gallery-insta">
                     <!--begin popup-gallery-->
                     <div class="popup-gallery popup-gallery-rounded portfolio-pic">
                        <a class="popup2" href="images\DSC_1166.jpg">
                        <img src="images\DSC_1166.jpg" class="width-100" alt="pic">
                        <span class="eye-wrapper"><i class="fa fa-search-plus eye-icon" style="font-size: 38px;"></i></span>
                        </a>
                     </div>
                     <!--end popup-gallery-->
                  </figure>
               </div>
               <!--end col-md-3 -->
               <!--begin col-md-3 -->
               <div class="col-md-3 col-sm-3 col-xs-6">
                  <figure class="gallery-insta">
                     <!--begin popup-gallery-->
                     <div class="popup-gallery popup-gallery-rounded portfolio-pic">
                        <a class="popup2" href="images\DSC_1167.jpg">
                        <img src="images\DSC_1167.jpg" class="width-100" alt="pic">
                        <span class="eye-wrapper"><i class="fa fa-search-plus eye-icon" style="font-size: 38px;"></i></span>
                        </a>
                     </div>
                     <!--end popup-gallery-->
                  </figure>
               </div>
               <!--end col-md-3 -->
               <!--begin col-md-3 -->
               <div class="col-md-3 col-sm-3 col-xs-6">
                  <figure class="gallery-insta">
                     <!--begin popup-gallery-->
                     <div class="popup-gallery popup-gallery-rounded portfolio-pic">
                        <a class="popup2" href="images\DSC_1168.jpg">
                        <img src="images\DSC_1168.jpg" class="width-100" alt="pic">
                        <span class="eye-wrapper"><i class="fa fa-search-plus eye-icon" style="font-size: 38px;"></i></span>
                        </a>
                     </div>
                     <!--end popup-gallery-->
                  </figure>
               </div>
               <!--end col-md-3 -->
               <!--begin col-md-3 -->
               <div class="col-md-3 col-sm-3 col-xs-6">
                  <figure class="gallery-insta">
                     <!--begin popup-gallery-->
                     <div class="popup-gallery popup-gallery-rounded portfolio-pic">
                        <a class="popup2" href="images\DSC_1169.jpg">
                        <img src="images\DSC_1169.jpg" class="width-100" alt="pic">
                        <span class="eye-wrapper"><i class="fa fa-search-plus eye-icon" style="font-size: 38px;"></i></span>
                        </a>
                     </div>
                     <!--end popup-gallery-->
                  </figure>
               </div>
               <!--end col-md-3 -->
               <!--begin col-md-3 -->
               <div class="col-md-3 col-sm-3 col-xs-6">
                  <figure class="gallery-insta">
                     <!--begin popup-gallery-->
                     <div class="popup-gallery popup-gallery-rounded portfolio-pic">
                        <a class="popup2" href="images\DSC_1170.jpg">
                        <img src="images\DSC_1170.jpg" class="width-100" alt="pic">
                        <span class="eye-wrapper"><i class="fa fa-search-plus eye-icon" style="font-size: 38px;"></i></span>
                        </a>
                     </div>
                     <!--end popup-gallery-->
                  </figure>
               </div>
               <!--end col-md-3 -->
            </div>
            <!--end row -->
         </div>
         <!--end container -->
      </section>
      <!--end gallery section -->
      <!--begin section-bg-3 section -->
      <section class="section-bg-3" id="start">
         <div class="home-section-overlay"></div>
         <!--begin container -->
         <div class="container">
            <!--begin row -->
            <div class="row">
               <!--begin col-md-5-->
               <div class="col-md-7">
                  <!--begin register-form-wrapper-->
                  <div class="register-form-wrapper wow bounceIn" data-wow-delay="0.5s" style="visibility: visible; animation-delay: 0.5s; animation-name: bounceIn;">
                     <h3>Get in Touch</h3>
                     <p>Velis demo enim quia tempor magnet.</p>
                     <!--begin form-->
                     <div>
                        <!--begin success message -->
                        <p class="register_success_box" style="display:none;">We received your message and you'll hear from us soon. Thank You!</p>
                        <!--end success message -->
                        <!--begin register form -->
                        <form id="register-form" class="register-form register" action="php/register.php" method="post">
                           <input class="register-input name-input white-input" required="" name="register_names" placeholder="Your Name*" type="text">
                           <input class="register-input name-email white-input" required="" name="register_email" placeholder="Email Adress*" type="email">
                           <select class="register-input white-input" required="" name="register_ticket">
                              <option value="">Your Goal</option>
                              <option value="Individual">To lose weight</option>
                              <option value="Professional">To stay fit</option>
                           </select>
                           <input value="Get Our Amazing Recipes" class="register-submit" type="submit">
                        </form>
                        <!--end register form -->
                        <p class="register-form-terms">No Credit Card &#8226; No Installation Required</p>
                     </div>
                     <!--end form-->
                  </div>
                  <!--end register-form-wrapper-->
               </div>
               <!--end col-md-5-->
            </div>
            <!--end row -->
         </div>
         <!--end container -->
      </section>
      <!--end cta section -->
      <!--begin footer -->
      <?php include 'footer.php';?>
      <!--end footer -->
      <!-- Load JS here for greater good =============================-->
      <?php include 'js.php';?>
   </body>
</html>